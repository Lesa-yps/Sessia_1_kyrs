#include <stdio.h>
#include <string.h>
//подключение моих модулей-функций
#include "const_struct.h"
#include "read_arr.h"
#include "print_arr.h"
#include "find_key.h"

int main(int argc, char *argv[])
{
    FILE *file;
    //массив хранит все фильмы из файла
    struct film films[MAX_COUNT];
    //количество элементов в массиве
    int n;
    //код ошибки программы
    int rc;
    //результат поиска элемента (индекс), если поиск будет
    int res;
    //проверка на количество переданных аргументов
    if (argc < 3 || argc > 4)
    {
        printf("Error: wrong count of argc.");
        for (int i = 0; i < argc; i++)
            printf("%s\n", argv[i]);
        return ERR_COUNT_ARGC;
    }
    //проверка на корректность поля поиска
    if ((strcmp(argv[place], "title") * strcmp(argv[place], "name") * strcmp(argv[place], "year")) != 0)
    {
        printf("Error: wrong place.");
        return ERR_PLACE;
    }
    //открытие файла и его проверка
    file = fopen(argv[file_name], "rt");
    if (file == NULL)
    {
        printf("Error: can't open file.");
        return ERR_OPEN;
    }
    //чтение файла в массив и попутная сортировка массива при вставке КАЖДОГО элемента + проверка на всякие ошибки
    rc = read_arr(file, films, &n, argv[place]);
    if (rc != OK)
    {
        if (rc == ERR_COUNT_STRUCT)
            printf("Error: too much films.");
        if (rc == ERR_READ)
            printf("Error: something wrong with reading file.");
        if (rc == ERR_EMPTY)
            printf("Error: file is empty.");
        return rc;
    }
    //вывод отсортированного массива, если не указан искомый элемент
    if (argc == 3)
        print_arr(films, n);
    //если указан искомый элемент, вызывается функция поиска, возвращающая индекс или -5 при его отсутствии
    else
    {

        res = find_key(films, n, argv[place], argv[find_place]);
        if (res == NOT_FOUND)
            printf("Not found");
        else
            printf("%s\n%s\n%d\n", (films[res]).title, (films[res]).name, (films[res]).year);
    }

    return rc;
}
