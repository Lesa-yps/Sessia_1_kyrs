#ifndef CONST_STRUCT_H
#define CONST_STRUCT_H

#define OK 0

#define ERR_PLACE 4
#define ERR_COUNT_ARGC 5

#define ERR_OPEN -1
#define ERR_EMPTY -2
#define ERR_COUNT_STRUCT -3
#define ERR_READ -4

#define NOT_FOUND -5
//нумерация переданных аргументов
#define file_name 1
#define place 2
#define find_place 3

#define MAX_LEN 25 + 1
#define MAX_COUNT 15
//структура
struct film
{
    char title[MAX_LEN];
    char name[MAX_LEN];
    int year;
};

#endif // CONST_STRUCT_H
