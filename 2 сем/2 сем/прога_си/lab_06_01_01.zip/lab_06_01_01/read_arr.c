#include "read_arr.h"

void input_sort(int *n, char what[], struct film one, struct film films[]);

int read_arr(FILE *file, struct film films[], int *n, char what[])
{
    int rc = OK;
    int count;
    struct film one;
    
    *n = 0;
    
    while (! rc)
    {
        //чтение одной структуры
        count = fscanf(file, "%s\n%s\n%d", one.title, one.name, &(one.year));
        //проверки всяконькие
        if (*n == MAX_COUNT)
            rc = ERR_COUNT_STRUCT;
        else if (count == 1 || count == 2)
            rc = ERR_READ;
        else if (count != 3)
            break;
        else
        {
            //вставляем считанный элемент на верное место в массив (сортировка)
            input_sort(n, what, one, films);
            (*n)++;
        }
    }
    //если файл пуст
    if (*n == 0)
        rc = ERR_EMPTY;

    return rc;
}

//вставляем считанный элемент на верное место в массив (сортировка)
void input_sort(int *n, char what[], struct film one, struct film films[])
{
    struct film two;

    for (int j = 0; j < (*n); j++)
    {
        if (((strcmp(what, "title") == 0) && (strncmp(one.title, (films[j]).title, MAX_LEN) < 0))\
            || ((strcmp(what, "name") == 0) && (strncmp(one.name, (films[j]).name, MAX_LEN) < 0))\
                || ((strcmp(what, "year") == 0) && (one.year < (films[j]).year)))
        {
            two = one;
            one = films[j];
            films[j] = two;
        }
    }
    films[*n] = one;
}
