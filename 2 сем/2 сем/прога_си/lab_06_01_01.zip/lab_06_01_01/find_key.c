#include "find_key.h"
//бинарный поиск
int find_key(struct film films[], int n, char what[], char key[])
{
    //левая граница
    int left = 0;
    //правая граница
    int right = n - 1;
    //середина
    int middle;
    //пока границы не пересеклись
    while (right >= left)
    {
        //вычисляем середину
        middle = left + (right - left) / 2;
        //если нашли элемент, возвращаем его индекс
        if (((strcmp(what, "title") == 0) && (strcmp(key, (films[middle]).title) == 0))\
            || ((strcmp(what, "name") == 0) && (strcmp(key, (films[middle]).name) == 0))\
            || ((strcmp(what, "year") == 0) && (strtol(key, NULL, 10) == (films[middle]).year)))
            return middle;
        //если середина больше искомого, сдвигаем правую границу
        else if (((strcmp(what, "title") == 0) && (strcmp(key, (films[middle]).title) < 0))\
                 || ((strcmp(what, "name") == 0) && (strcmp(key, (films[middle]).name) < 0))\
                 || ((strcmp(what, "year") == 0) && (strtol(key, NULL, 10) < (films[middle]).year)))
            right = middle - 1;
        //если середина меньше искомого, сдвигаем левуую границу
        else
            left = middle + 1;
    }
    //если границы пересеклись, то искомого элемента нет (-5)
    return NOT_FOUND;
}
