#ifndef PRINT_ARR_H
#define PRINT_ARR_H

#include <stdio.h>

#include "const_struct.h"
//вывод отсортированного массива
void print_arr(struct film films[], int n);

#endif // PRINT_ARR_H
